﻿using System;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }

        struct Boxing
        {
            void M(string a)
            {
                object obj = 42;                // implicit conversion Int32 ~> Object
                string path = a + '/' + obj;    // implicit conversion Char ~> Object
                int code = this.GetHashCode();  // non-overriden virtual method call on struct
                string caseA = E.A.ToString();  // the same, virtual call
                IComparable comparable = E.A;   // valuetype conversion to interface type
                Action<string> action = this.M; // delegate from value type method
                Type type = this.GetType();     // GetType() call is always virtual
            }

            enum E { A, B, C }
        }
    }
}
